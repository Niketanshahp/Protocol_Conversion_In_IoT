Compilation commands
1) gcc -o server server.c
2) gcc -o client1 client1.c
3) gcc -o serial1 serial1.c

steps to run zigbee
1) run server in Raspberry Pi
2) run serial1 in client 2
3) run client1 in client1
