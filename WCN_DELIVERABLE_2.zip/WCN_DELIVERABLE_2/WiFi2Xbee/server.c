#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include<netinet/udp.h>   //Provides declarations for udp header
#include<netinet/ip.h>    //Provides declarations for ip header

/*For serial communication*/
 #include <errno.h>
#include <fcntl.h> 
#include <termios.h>
#include <unistd.h>

#define PORT     	8080
#define HELLO_LENGTH	1024
#define MAXLENGTH 	HELLO_LENGTH+20
#define MAXPACKETS 	100
#define DELIMITER	0x7e
#define FRAMESIZE	2

/*set up serial interface for transmission through xbee module*/
int set_interface_attribs(int fd, int speed)
{
    struct termios tty;

    if (tcgetattr(fd, &tty) < 0) {
        printf("Error from tcgetattr: %s\n", strerror(errno));
        return -1;
    }

    cfsetospeed(&tty, (speed_t)speed);
    cfsetispeed(&tty, (speed_t)speed);

    tty.c_cflag |= (CLOCAL | CREAD);    /* ignore modem controls */
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;         /* 8-bit characters */
    tty.c_cflag &= ~PARENB;     /* no parity bit */
    tty.c_cflag &= ~CSTOPB;     /* only need 1 stop bit */
    tty.c_cflag &= ~CRTSCTS;    /* no hardware flowcontrol */

    /* setup for non-canonical mode */
    tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    tty.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    tty.c_oflag &= ~OPOST;

    /* fetch bytes as they become available */
    tty.c_cc[VMIN] = 1;
    tty.c_cc[VTIME] = 2;

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        printf("Error from tcsetattr: %s\n", strerror(errno));
        return -1;
    }
    return 0;
}


void getFrame(unsigned char src[],int len,unsigned char dest[])
{

	/*Insert delimiter as start byte*/
	dest[0]=DELIMITER;

	/*Insert frame id, buffer length and buffer to dest buffer*/
	int i=0;
	for(;i<len;i++)
	{
	    dest[i+1]=src[i];
	}


	/*Insert delimiter as stop byte*/
	dest[i+1]=DELIMITER;
}

int main() 
{

    int sockfd,i=0;
    unsigned char buffer[MAXLENGTH];
    //char buffer2[MAXLENGTH];

    struct sockaddr_in servaddr, cliaddr1,cliaddr2;
     
    // Creating socket file descriptor
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM , 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }
     
    memset(&servaddr, 0, sizeof(servaddr));
    memset(&cliaddr1, 0, sizeof(cliaddr1));
    memset(&cliaddr2, 0, sizeof(cliaddr2));

     
    // Filling server information
    servaddr.sin_family    = AF_INET; // IPv4
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);
     
    // Bind the socket with the server address
    if ( bind(sockfd, (const struct sockaddr *)&servaddr, 
            sizeof(servaddr)) < 0 )
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
     
    int cli1len, n, m ;

    cli1len = sizeof(cliaddr1); 

    /*Initialize serial port*/
    char *portname = "/dev/ttyUSB1";
    int fd;
    int wlen;

    fd = open(portname, O_RDWR | O_NOCTTY | O_SYNC);
    if (fd < 0) {
        printf("Error opening %s: %s\n", portname, strerror(errno));
        return -1;
    }
    /*baudrate 115200, 8 bits, no parity, 1 stop bit */

    set_interface_attribs(fd, B9600);

    /* simple output */
    wlen = write(fd, "Hello!\n", 7);
    if (wlen != 7) {
        printf("Error from write: %d, %d\n", wlen, errno);
    }
    tcdrain(fd);    /* delay for output */
       

     /*Initialize serial port end*/
    int bytes;
    int count=0;
    for(i=0;i<MAXPACKETS;)
    { 
	count++;
	n = recvfrom(sockfd, buffer, MAXLENGTH, 
                MSG_WAITALL, ( struct sockaddr *) &cliaddr1,
                &cli1len);

    	struct iphdr *iph = (struct iphdr*)buffer;

	i++;
	unsigned char serialBuf[MAXLENGTH];
	int j=0;
	getFrame(buffer,n,serialBuf);

    	printf("about to write n=%d\n",n+FRAMESIZE);
	printf("\n");
	for(int i=0;i<n+FRAMESIZE;i++)
	{
	    printf("%02x",serialBuf[i]);
	}
	int wrlen=0;
	while(wrlen<n)
	{
		wrlen=write(fd, serialBuf, n+FRAMESIZE);
		printf("\nWrite %d:\n", wrlen);
		
	}

	printf("\ncount=%d\n",count);
    }
    return 0;
}

