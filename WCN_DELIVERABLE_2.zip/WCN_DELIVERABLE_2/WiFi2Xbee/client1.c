#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
 
#define PORT     	8080
#define HELLO_LENGTH 	1024
#define MAXPACKETS 	100
#define SLEEP_INTERVAL 	1000000

/*SERVER IP Address*/
char *ip = "10.3.141.1";
 
// Driver code
int main() 
{
    int sockfd;
    unsigned char hello[HELLO_LENGTH];
    unsigned char val=0x30;

    /*Prepare String To be Transmitted*/
    int i=0;
    for(;i<HELLO_LENGTH-1;i++)
    {
	hello[i]=val;
     	val++;
	if(val==0x3a)
	    val=0x41;
	else if(val==0x5b)
	    val=0x61;
	else if(val==0x7b)
	    val=0x30;
    }
    hello[i]='\0';
    struct sockaddr_in     servaddr;
 
    // Creating socket file descriptor
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }
 
    memset(&servaddr, 0, sizeof(servaddr));
     
    // Filling server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    //servaddr.sin_addr.s_addr = inet_addr(ip);
    servaddr.sin_addr.s_addr = INADDR_ANY;
     
    int n, len;
    i=0 ;
    for(i=0;i<MAXPACKETS;i++)
    {  
	char tempBuf[HELLO_LENGTH+100];
	sprintf(tempBuf,"%s id %d\n",hello,i);
	sendto(sockfd, (const char *)tempBuf, strlen(tempBuf),
        MSG_CONFIRM, (const struct sockaddr *) &servaddr, 
            sizeof(servaddr));

        printf("Hello message sent %d time \n",i);
        usleep(SLEEP_INTERVAL); 
    }
    close(sockfd);
    return 0;
}
