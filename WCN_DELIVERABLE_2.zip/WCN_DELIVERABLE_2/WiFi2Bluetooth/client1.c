#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/time.h>
 
#define PORT     8080
#define MAXLINE 915
#define HELLO_LENGTH    900


char *ip = "10.3.141.1";	//Change the IP accordingly
 
long int timeDifference(struct timeval *endTime,struct timeval *startTime)
{
    return (endTime->tv_sec * 1000000 + endTime->tv_usec)
              - (startTime->tv_sec * 1000000 + startTime->tv_usec);
}

int main() {
    struct timeval *tv1,*tv2;
    tv1=(struct timeval*)malloc(sizeof(struct timeval));
    tv2=(struct timeval*)malloc(sizeof(struct timeval));
    int sockfd,i=0;
    char buffer[MAXLINE];
    unsigned char hello[HELLO_LENGTH];
    unsigned char val=0x30;
//    char *hello = "client1";
    for(i=0;i<HELLO_LENGTH-1;i++)
    {
        hello[i]=val;
        val++;
        if(val==0x3a)
            val=0x41;
        else if(val==0x5b)
            val=0x61;
        else if(val==0x7b)
            val=0x30;
    }
    hello[i]='\0';

    struct sockaddr_in     servaddr;
 
    // Creating socket file descriptor
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }
 
    memset(&servaddr, 0, sizeof(servaddr));
     
    // Filling server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = inet_addr(ip);
     
    int n, len;
    i=0;
    for(i=0;i<100;i++)
    {  
	char tempBuf[MAXLINE];
	sprintf(tempBuf,"%s id %d\n",hello,i);
        gettimeofday(tv1, NULL);
        printf("Start time in us : %ld",tv1->tv_sec * 1000000 + tv1->tv_usec);
	sendto(sockfd, (const char *)tempBuf, strlen(tempBuf),
        MSG_CONFIRM, (const struct sockaddr *) &servaddr, 
            sizeof(servaddr));
         gettimeofday(tv2, NULL);
         printf("End time in us : %ld",tv2->tv_sec * 1000000 + tv2->tv_usec);


//    usleep(1000);
    printf("Hello message sent %d time \n",i);
   }
    close(sockfd);
    return 0;
}
