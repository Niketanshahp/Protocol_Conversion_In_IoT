Compilation commands
1) gcc -o server server.c -lbluetooth
2) gcc -o client2 client2.c -lbluetooth
3) gcc -o client1 client1.c

Steps to be followed to run the WiFi2Bluetooth
1) Run server.c in Raspberry pi
2) Run client2.c in client 2
3) Run client1.c in client 1
