Compilation commands
1) gcc -o server server.c -lbluetooth
2) gcc -o client2 client2.c -lbluetooth
3) gcc -o client1 client1.c
4) gcc -o serial serial1.c

Steps to be followed to run the WiFi2Bluetooth
1) Run server.c on Raspberry pi
2) Run client2.c on one process at client 2
3) Run serial1.c on other process at client 2
4) Run client1.c in client 1
