Steps to be followed:

1. Compile using gcc compiler.
2. Run server on one machine
3. Run client2 on different machine
4. Run client1 on different machine
